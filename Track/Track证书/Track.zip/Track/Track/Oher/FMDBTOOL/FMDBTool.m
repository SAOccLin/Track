//
//  FMDBTool.m
//  NetWorkTool
//
//  Created by lanou on 16/5/23.
//  Copyright © 2016年 zxl. All rights reserved.
//


#import "FMDBTool.h"

@interface FMDBTool ()

@property(nonatomic,strong)FMDatabase *db;

@end


@implementation FMDBTool

//单例
+ (instancetype)shareDataBase{
    static FMDBTool *tool = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        tool = [[FMDBTool alloc]init];
    });
    return tool;
}
//初始化创建数据库
- (instancetype)init{
    self = [super init];
    if (self) {
        NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];
        NSString *docuPath = [path stringByAppendingPathComponent:@"Track.sqlite"];
//        NSLog(@"%@",docuPath);
        _db = [[FMDatabase alloc]initWithPath:docuPath];
//        NSLog(@"%@",docuPath);
        [_db open];
        BOOL success1 = [self.db executeUpdate:@"CREATE TABLE IF NOT EXISTS FriendsList (id text not null, name TEXT , phone text ,imageData text)"];
         
         if (success1) {
//             NSLog(@"创建好友列表成功");
         } else {
//             NSLog(@"创建好友列表失败");
         }
        BOOL success2 = [self.db executeUpdate:@"CREATE TABLE IF NOT EXISTS  FriendsRequest (id text not null, name TEXT ,imageData text)"];
        
        if (success2) {
//            NSLog(@"创建请求好友信息列表成功");
        } else {
//            NSLog(@"创建请求好友信息列表失败");
        }
        BOOL success3 = [self.db executeUpdate:@"CREATE TABLE IF NOT EXISTS  PositionRequest (id text not null, name TEXT ,requestTime text,imageData text)"];
        
        if (success3) {
//            NSLog(@"创建请求位置信息列表成功");
        } else {
//            NSLog(@"创建请求位置信息列表失败");
        }
        BOOL success4 = [self.db executeUpdate:@"CREATE TABLE IF NOT EXISTS MyMessage (id text not null, name TEXT , phone text ,company text,job text,online text,imageData text)"];
        
        if (success4) {
//            NSLog(@"创建个人信息列表成功");
        } else {
//            NSLog(@"创建个人信息列表失败");
        }
        BOOL success5 = [self.db executeUpdate:@"CREATE TABLE IF NOT EXISTS PassWord ( name TEXT , passWord text)"];
        if (success5) {
//            NSLog(@"创建账号密码列表成功");
        } else {
//            NSLog(@"创建账号密码列表失败");
        }
        BOOL success6 = [self.db executeUpdate:@"CREATE TABLE IF NOT EXISTS NOLog ( NOLog text)"];
        if (success6) {
//            NSLog(@"创建在线判断成功");
        } else {
//            NSLog(@"创建在线判断失败");
        }
        [_db close];
    }
    return self;
}
//判断帐号登录状态
-(BOOL)checkOnline{
    [self.db open];
    // 查询数据
    FMResultSet *set = [_db executeQuery:@"SELECT * FROM MyMessage;"];
    NSMutableArray *arr = [NSMutableArray array];
    while ([set next]) {
        UpDataMessage *nl = [[UpDataMessage alloc]init];
        nl.name = [set objectForColumnName:@"name"];
        nl.phone = [set objectForColumnName:@"phone"];
        nl.company = [set objectForColumnName:@"company"];
        nl.job = [set objectForColumnName:@"job"];
        nl.userId = [set objectForColumnName:@"id"];
        nl.online = [set objectForColumnName:@"online"];
        nl.portrait= [set objectForColumnName:@"imageData"];
//        NSLog(@"登录状态判断 %@",nl.online);
        [arr addObject:nl];
        if ([[set objectForColumnName:@"online"] isEqualToString:@"1"]) {
            [_db close];
            return YES;
        }else{
            [_db close];
            return NO;
        }
    }
    return NO;
}
//写入判断状态
- (void)NOLog{
    [self.db open];
    BOOL resut =[self.db executeStatements:[NSString stringWithFormat:@"insert into NOLog values('%@');",@"0"]];
    if (resut==YES) {
//        NSLog(@"写入好友列表成功");
    }else{
//        NSLog(@"写入好友列表失败");
    }

}
//搜素判断状态
-(NSString *)selectNOLog{
    [self.db open];
    FMResultSet *set = [self.db executeQuery:@"SELECT NOlog FROM NOLog;"];
    NSString *ss=nil;
    while ([set next]) {
        ss = [set objectForColumnName:@"NOLog"];
    }
    [self.db close];
    return ss;
}
//删除判断状态
- (void)deleteNOLog{
    [self.db open];
    BOOL resut = [self.db executeStatements:[NSString stringWithFormat:@"DELETE FROM NOLog"]];
    if (resut==YES) {
//        NSLog(@"删除判断状态成功");
    }else{
//        NSLog(@"删除判断状态失败");
    }
    [self.db close];
}

//写入好友列表
- (void)FriendsList:(NSArray<FriendsList *> *)array{
    [self.db open];
    for (FriendsList *nl in array) {
         BOOL resut =[self.db executeStatements:[NSString stringWithFormat:@"insert into FriendsList values('%@','%@','%@','%@');",nl.userId,nl.name,nl.phone,nl.imageData]];
        if (resut==YES) {
//            NSLog(@"写入好友列表成功");
        }else{
//            NSLog(@"写入好友列表失败");
        }
//        NSLog(@"写入列表%d",result);
    }
    [self.db close];
}

//搜素好友列表
-(NSArray *)selectFriendsList{
    [_db open];
    FMResultSet *set = [self.db executeQuery:@"SELECT id, name, imageData FROM FriendsList;"];
    NSArray *arr = [NSArray array];
    while ([set next]) {
        FriendsList *an = [[FriendsList alloc]init];
        an.userId = [set objectForColumnName:@"id"];
        an.name = [set objectForColumnName:@"name"];
        an.imageData = [set objectForKeyedSubscript:@"imageData"];
        arr = [arr arrayByAddingObject:an];
//        NSLog(@"逗比%@",arr);
    }
    [self.db close];
    return arr;
}

//删除好友列表数据
- (void)deleteFriendsList{
    [self.db open];
    BOOL resut = [self.db executeStatements:[NSString stringWithFormat:@"DELETE FROM FriendsList"]];
    if (resut==YES) {
//        NSLog(@"删除好友列表成功");
    }else{
//        NSLog(@"删除好友列表失败");
    }
    [self.db close];
}

//写入请求好友信息列表
- (void)insertFriendsRequest:(NSArray<NotificationList *> *)array{
    NSLock *lock =[[NSLock alloc]init];
    [lock lock];
    [self.db open];
    for (NotificationList *nl in array) {
        BOOL resut = [self.db executeStatements:[NSString stringWithFormat:@"insert into FriendsRequest values('%@','%@','%@');",nl.userId,nl.name,nl.imageData]];
        if (resut==YES) {
//            NSLog(@"写入请求好友信息列表成功");
        }else{
//            NSLog(@"写入请求好友信息列表失败");
        }
    }
    [self.db close];
    [lock unlock];

}

//搜素请求好友信息列表
-(NSArray *)selectFriendsRequest{
    [_db open];
    FMResultSet *set = [_db executeQuery:@"select *from FriendsRequest;"];
//    FMResultSet *result = [self.db executeQuery:@"SELECT id, name, age FROM t_student WHERE age > 25;"];
    NSArray *arr = [NSArray array];
    while ([set next]) {
        NotificationList *an = [[NotificationList alloc]init];
        an.userId = [set objectForColumnName:@"id"];
        an.name = [set objectForColumnName:@"name"];
        an.imageData = [set objectForKeyedSubscript:@"imageData"];
        arr = [arr arrayByAddingObject:an];
//        NSLog(@"弱智1%@",arr);
    }
    [self.db close];
    return arr;
}
//删除指定好友请求信息
-(void)deleteFriendsRequest:(NotificationList *)list{
    [self.db open];
    BOOL resut = [self.db executeStatements:[NSString stringWithFormat:@"delete from FriendsRequest where id = '%@' and name = '%@';",list.userId,list.name]];
    if (resut==YES) {
//        NSLog(@"删除指定好友请求信息成功");
    }else{
//        NSLog(@"删除指定好友请求信息失败");
    }
    [self.db close];
}

//删除好友请求列表
- (void)deleteFriendsRequest{
    [self.db open];
    BOOL resut = [self.db executeStatements:[NSString stringWithFormat:@"DELETE FROM FriendsRequest"]];
    if (resut==YES) {
//        NSLog(@"删除好友请求列表成功");
    }else{
//        NSLog(@"删除好友请求列表失败");
    }
    [self.db close];
}

//写入位置请求信息列表
- (void)insertPositionRequest:(NSArray<NotificationList *> *)array{
    NSLock *lock =[[NSLock alloc]init];
    [lock lock];
    [self.db open];
    for (NotificationList *nl in array) {
        BOOL resut = [self.db executeStatements:[NSString stringWithFormat:@"insert into PositionRequest values('%@','%@','%@','%@');",nl.userId,nl.name,nl.requestTime,nl.imageData]];
        if (resut==YES) {
//            NSLog(@"写入位置请求信息列表成功");
        }else{
//            NSLog(@"写入位置请求信息列表失败");
        }
    }
    [self.db close];
    [lock unlock];
    
}

//搜素位置请求信息列表
-(NSArray *)selectPositionRequest{
    [_db open];
    FMResultSet *set = [_db executeQuery:@"select *from PositionRequest;"];
    //    FMResultSet *result = [self.db executeQuery:@"SELECT id, name, age FROM t_student WHERE age > 25;"];
    NSArray *arr = [NSArray array];
    while ([set next]) {
        NotificationList *an = [[NotificationList alloc]init];
        an.userId = [set objectForColumnName:@"id"];
        an.name = [set objectForColumnName:@"name"];
        an.requestTime = [set objectForKeyedSubscript:@"requestTime"];
        an.imageData = [set objectForKeyedSubscript:@"imageData"];
        arr = [arr arrayByAddingObject:an];
//        NSLog(@"弱智2%@",arr);
    }
    [self.db close];
    return arr;
}

//删除指定位置请求信息
-(void)deletePositionRequest:(NotificationList *)list{
    [self.db open];
    BOOL resut = [self.db executeStatements:[NSString stringWithFormat:@"delete from PositionRequest where id = '%@' and name = '%@' and requestTime = '%@';",list.userId,list.name,list.requestTime]];
    if (resut==YES) {
//        NSLog(@"删除指定位置请求信息成功");
    }else{
//        NSLog(@"删除指定位置请求信息失败");
    }
    [self.db close];
}

//删除位置请求列表
- (void)deletePositionRequest{
    [self.db open];
    BOOL resut = [self.db executeStatements:[NSString stringWithFormat:@"DELETE FROM PositionRequest"]];
    if (resut==YES) {
//        NSLog(@"删除位置请求列表成功");
    }else{
//        NSLog(@"删除位置请求列表失败");
    }
    [self.db close];
}




//写入个人信息列表
- (void)insertMyMessage:(NSArray<UpDataMessage *> *)array{
    [self.db open];
    for (UpDataMessage *nl in array) {
         BOOL resut = [self.db executeStatements:[NSString stringWithFormat:@"insert into MyMessage values('%@','%@','%@','%@','%@','%@','%@');",nl.userId,nl.name,nl.phone,nl.company,nl.job,nl.online,nl.portrait]];
        if (resut==YES) {
//            NSLog(@"写入个人信息列表成功");
        }else{
//            NSLog(@"写入个人信息列表失败");
        }
    }
    [self.db close];
}
//修改用户名
-(void)upDateMyMessage:(NSString *)name{
    [_db open];
   BOOL resut = [_db executeUpdate:[NSString stringWithFormat:@"update MyMessage set name = '%@';",name]
                 ];
    if (resut==YES) {
//        NSLog(@"修改用户名成功");
    }else{
//        NSLog(@"修改用户名失败");
    }
    [_db close];
}

//搜素个人信息
-(NSArray *)selectMyMessage{
    [_db open];
    FMResultSet *set = [_db executeQuery:@"select *from MyMessage;"];
    NSArray *arr = [NSArray array];
    while ([set next]) {
        UpDataMessage *an = [[UpDataMessage alloc]init];
        an.userId = [set objectForColumnName:@"id"];
        an.name = [set objectForColumnName:@"name"];
        an.phone = [set objectForKeyedSubscript:@"phone"];
        an.portrait = [set objectForKeyedSubscript:@"imageData"];
        arr = [arr arrayByAddingObject:an];
    }
    [self.db close];
    return arr;
    
}
//删除请求列表
- (void)deleteMyMessage{
    [self.db open];
    BOOL resut = [self.db executeStatements:[NSString stringWithFormat:@"DELETE FROM MyMessage"]];
    if (resut==YES) {
//        NSLog(@"删除个人信息列表成功");
    }else{
//        NSLog(@"删除个人信息列表失败");
    }
    [self.db close];
}

//写入个人账号密码
-(void)insertPassWord:(NSArray< PassWord*>*)array{
    [self.db open];
    for (PassWord *nl in array) {
        BOOL resut = [self.db executeStatements:[NSString stringWithFormat:@"insert into PassWord values('%@','%@');",nl.name,nl.passWord]];
        if (resut==YES) {
//            NSLog(@"写入账号密码列表成功");
        }else{
//            NSLog(@"写入账号密码列表失败");
        }
    }
    [self.db close];
}
//搜素个人账号密码
-(NSArray *)selectPassWord{
    [_db open];
    FMResultSet *set = [_db executeQuery:@"select *from PassWord;"];
    NSArray *arr = [NSArray array];
    while ([set next]) {
        PassWord *an = [[PassWord alloc]init];;
        an.name = [set objectForColumnName:@"name"];
        an.passWord = [set objectForColumnName:@"passWord"];
        arr = [arr arrayByAddingObject:an];
    }
    [self.db close];
    return arr;
}
//删除个人账号密码
-(void)deletePassWord{
    [self.db open];
    BOOL resut = [self.db executeStatements:[NSString stringWithFormat:@"DELETE FROM PassWord"]];
    if (resut==YES) {
//        NSLog(@"删除账号密码列表成功");
    }else{
//        NSLog(@"删除账号密码列表失败");
    }
    [self.db close];
}

@end
