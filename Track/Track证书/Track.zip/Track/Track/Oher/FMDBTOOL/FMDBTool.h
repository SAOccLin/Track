//
//  FMDBTool.h
//  NetWorkTool
//
//  Created by lanou on 16/5/23.
//  Copyright © 2016年 zxl. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FriendsList.h"
#import "NotificationList.h"
#import "UpDataMessage.h"
#import "PassWord.h"

@interface FMDBTool : NSObject

/**单例 */
+ (instancetype)shareDataBase;

//判断帐号登录状态
-(BOOL)checkOnline;

//写入判断状态
- (void)NOLog;
//搜素判断状态
-(NSString *)selectNOLog;
//删除判断状态
- (void)deleteNOLog;

//写入好友列表
- (void)FriendsList:(NSArray<FriendsList *> *)array;
//搜素好友列表
-(NSArray *)selectFriendsList;
//删除好友列表
- (void)deleteFriendsList;

//写入请求好友信息列表
- (void)insertFriendsRequest:(NSArray<NotificationList *> *)array;
//搜素请求好友信息列表
-(NSArray *)selectFriendsRequest;
//删除指定好友请求信息
-(void)deleteFriendsRequest:(NotificationList *)list;
//删除好友请求列表
- (void)deleteFriendsRequest;


//写入位置请求信息列表
- (void)insertPositionRequest:(NSArray<NotificationList *> *)array;
//搜素位置请求信息列表
-(NSArray *)selectPositionRequest;
//删除指定位置请求信息
-(void)deletePositionRequest:(NotificationList *)list;
//删除位置请求列表
- (void)deletePositionRequest;



//搜素个人信息
-(NSArray *)selectMyMessage;
//修改用户名
-(void)upDateMyMessage:(NSString *)name;
//写入个人信息列表
- (void)insertMyMessage:(NSArray<UpDataMessage *> *)array;
//删除请求列表
- (void)deleteMyMessage;

//写入个人账号密码
-(void)insertPassWord:(NSArray *)array;
//搜素个人账号密码
-(NSArray *)selectPassWord;
//删除个人账号密码
-(void)deletePassWord;
@end
