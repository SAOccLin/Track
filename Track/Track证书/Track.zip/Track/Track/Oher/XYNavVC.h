//
//  XYNavVC.h
//  Track
//
//  Created by Mac on 16/8/15.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XYNavVC : UINavigationController

@end
