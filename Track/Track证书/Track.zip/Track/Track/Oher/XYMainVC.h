//
//  XYMainVC.h
//  Track
//
//  Created by Mac on 16/8/15.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XYMainVC : UITabBarController
@property (nonatomic,strong)NSDictionary *dic;
@property (nonatomic,strong) XYContactVC *contactVC;
@end
