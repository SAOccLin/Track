//
//  AddButton.h
//  Track
//
//  Created by apple on 2016/11/13.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddButton : UIButton
-(instancetype)initWithFrame:(CGRect)frame imageName:(NSString *)imageName labText:(NSString *)labText;
@end
