//
//  AddText.h
//  Track
//
//  Created by apple on 2016/11/13.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddText : UIView
//文本框
@property (nonatomic,strong) UITextField *textField;

//光标颜色
@property (nonatomic,strong) UIColor *cursorColor;


@end
