//
//  XYAddVC.h
//  Track
//
//  Created by Mac on 16/8/16.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddText.h"
@interface XYAddVC : UIViewController
@property (nonatomic,strong)AddText *phoneField;

@end
