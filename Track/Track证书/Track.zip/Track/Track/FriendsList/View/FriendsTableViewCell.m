//
//  FriendsTableViewCell.m
//  Track
//
//  Created by apple on 2016/11/13.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "FriendsTableViewCell.h"
@interface FriendsTableViewCell()
@property (nonatomic,strong)UIView *line;

@end
@implementation FriendsTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    _line = [[UIView alloc]initWithFrame:CGRectZero];
    
    _line.frame =CGRectMake(17, CGRectGetHeight(self.frame), CGRectGetWidth(self.frame)-34, 1);
    _line.backgroundColor = [UIColor colorWithWhite:1 alpha:0.25];
    [self addSubview:_line];
    
    self.lab.backgroundColor = [UIColor clearColor];
    self.lab.textColor = [UIColor whiteColor];
    self.backgroundColor = [UIColor clearColor];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
