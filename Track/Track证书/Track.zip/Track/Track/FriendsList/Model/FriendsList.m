//
//  FriendsList.m
//  Track
//
//  Created by apple on 16/9/5.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "FriendsList.h"
#import "UIImageView+WebCache.h"
@implementation FriendsList
-(void)stValue:(NSDictionary *)dic{
    self.name = [dic valueForKey:@"name"];
    self.phone = [dic valueForKey:@"ltitle"];
    self.portrait = [dic valueForKey:@"url"];
    self.userId = [dic valueForKey:@"id"];
    NSString *ss =[NSString stringWithFormat:@"http://api.sunsyi.com:8081/portrait/%@",_portrait];
    [[SDWebImageManager sharedManager] downloadImageWithURL:[NSURL URLWithString:ss] options:0  progress:^(NSInteger receivedSize, NSInteger expectedSize)
     {
         //处理下载进度
     } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, BOOL finished, NSURL *imageURL) {
         if (error) {
                          NSLog(@"%@",error);
         }
         if (image) {
             NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
             NSString *filePath = [[paths objectAtIndex:0] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.png",self.name]];   // 保存文件的名称
             [UIImagePNGRepresentation(image)writeToFile: filePath    atomically:YES];
//             NSLog(@"完成");
         }
     }];

}
//空实现
- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}
@end
