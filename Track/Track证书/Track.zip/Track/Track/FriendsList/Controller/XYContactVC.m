//
//  XYContactVC.m
//  Track
//
//  Created by maralves on 16/9/4.
//  Copyright © 2016年 Mac. All rights reserved.
//


#import "FriendsList.h"


@interface XYContactVC ()


@property(nonatomic,assign)NSIndexPath *index;
@property(nonatomic,assign)BOOL cellRequest;//是否正在请求好友位置
@property(nonatomic,assign)NSNumber *add;
@property (nonatomic,strong) Reachability *hostReach;
@property (nonatomic,strong) UIBarButtonItem *delcedBtn;
@property(nonatomic,strong) UILabel *headLabel;//下拉刷新头部视图
@property(nonatomic,assign) BOOL isRequesting;
@property(nonatomic,assign) CGFloat contentSizeY;
@property (nonatomic,strong) AFHTTPSessionManager *manager;
@property (nonatomic,assign) int a;
@property (nonatomic,strong)NSURLSessionDataTask *post;
@property (nonatomic,strong)NSArray *ar;
@property (nonatomic,strong)NSString *friendName;
@property (nonatomic,assign)NSInteger isFirst;
@property (nonatomic,strong)UIView *warningView;
@property (nonatomic,strong)NSString *phone;
@end

@implementation XYContactVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.isFirst =0;
    setNav;
    
    
    //添加右边按钮
    UIButton *addBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 30, 30)];
    addBtn.layer.contents = (id)[UIImage imageNamed:@"添加图片.png"].CGImage;
    [addBtn addTarget:self action:@selector(addContact) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *temporaryBarButtonItem1 = [[UIBarButtonItem alloc] initWithCustomView:addBtn];
    self.navigationItem.rightBarButtonItem=temporaryBarButtonItem1;
    
    [self tableViewSetUp];
    
    setWaring;
}
//隐藏警告
-(void)hideView{
    self.warningView.hidden = YES;
    self.warningView.userInteractionEnabled = NO;
    self.navigationController.navigationBarHidden = NO;
}
//显示警告
-(void)NotHideView{
    self.warningView.hidden = NO;
    self.warningView.userInteractionEnabled = YES;
    self.navigationController.navigationBarHidden = YES;
}
-(void)goToSetLocation{
    
    //判断版本是否大于10.0
    if (NSFoundationVersionNumber >NSFoundationVersionNumber_iOS_9_x_Max) {
        //注意首字母改成了大写，prefs->Prefs
        NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
        NSDictionary *dic = [NSDictionary dictionary];
        [[UIApplication sharedApplication] openURL:url options:dic completionHandler:nil];
    }else{
       [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"prefs:root=LOCATION_SERVICES"]];
    }
}
//表示图设置
-(void)tableViewSetUp{
    _tableView.backgroundColor = [UIColor clearColor];
    //去除分割线
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    //注册cell
    [_tableView registerNib:[UINib nibWithNibName:@"FriendsTableViewCell" bundle:nil] forCellReuseIdentifier:@"cell"];
    
    _delcedBtn=[[UIBarButtonItem alloc]initWithTitle:@"编辑好友" style:UIBarButtonItemStylePlain target:self action:@selector(changeing)];
    
    
    _a=1;
    self.navigationItem.leftBarButtonItem=_delcedBtn;

    _cellRequest=NO;
    
    //头部刷新界面
    _headLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, -50,[UIScreen mainScreen].bounds.size.width, 50)];
    _headLabel.textAlignment = NSTextAlignmentCenter;
    [self.tableView addSubview:_headLabel];
    
    UIPinchGestureRecognizer *nieHe = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(nieHe)];
    [_tableView addGestureRecognizer:nieHe];
    _isRequesting = NO;

}
-(void)nieHe{
    [_post cancel];
    [SVProgressHUD dismiss];
    _cellRequest = NO;
}
-(void)changeing{
    if (_a==1) {
        [_tableView setEditing:YES animated:YES];
        _a=0;
    }else{
        [_tableView setEditing:NO animated:YES];
        _a=1;
    }
}
//下拉刷新
-(void)getURLData{
    _isRequesting = YES;
    NSString *url = [NSString stringWithFormat:@"%@friendList",MYURL];
    url= [url stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    NSLog(@"获取好友列表接口：%@",url);
    _post = [self.manager GET:url parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject  options:(NSJSONReadingMutableLeaves) error:nil];
        NSLog(@"获取好友列表返回信息:%@",dict);
        self.contactArr =nil;
        for (NSDictionary *dic in dict) {
            FriendsList * list = [[FriendsList alloc]init];
            [list stValue:dic];
//            NSLog(@"ssddff-%@",list);
            [self.contactArr insertObject:list atIndex:0];
//            NSLog(@"sdfwkj-%@",self.contactArr);
        }
        [[FMDBTool shareDataBase] deleteFriendsList];
        [[FMDBTool shareDataBase] FriendsList:self.contactArr];
        [[FMDBTool shareDataBase] selectFriendsList];
        dispatch_async(dispatch_get_main_queue(), ^{
            _isRequesting = NO;
            [self.tableView reloadData];
            _contentSizeY = self.tableView.contentSize.height - self.tableView.frame.size.height;
            _tableView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
        });
    } failure:nil];

}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (self.isFirst>=2) {
        if (scrollView.contentOffset.y <= -50) {
            _headLabel.text = @"松开刷新";
            _headLabel.textColor = [UIColor whiteColor];
            _headLabel.backgroundColor = [UIColor grayColor];
        }else{
            _headLabel.text = @"下拉刷新";
        }
        self.isFirst++;
    }
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    if (scrollView.contentOffset.y <= -50) {
        _headLabel.text = @"正在刷新";
        _headLabel.textColor = [UIColor whiteColor];
        _headLabel.backgroundColor = [UIColor grayColor];
        [UIView animateWithDuration:0.3 animations:^{
            _tableView.contentInset = UIEdgeInsetsMake(50, 0, 0, 0);
        }];
        [self getURLData];
    }else if (scrollView.contentOffset.y >= _contentSizeY+50){
        
        [UIView animateWithDuration:0.3 animations:^{
            _tableView.contentInset = UIEdgeInsetsMake(0, 0, 50, 0);
        }];
        [self getURLData];
    }
}


//跳转到添加好友界面
-(void)addContact{
    XYAddVC *addVC=[[XYAddVC alloc]init];
    [self.navigationController pushViewController:addVC animated:NO];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.contactArr.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}

//进入或退出cell的编辑模式
-(void)setEditing:(BOOL)editing animated:(BOOL)animated{
    /*首先调用父类的方法*/
    [super setEditing:editing animated:animated];
    if (editing) {
        /*使tableView处于编辑状态*/
        [self.tableView setEditing:editing animated:animated];

    }else{
        [_tableView endEditing:editing];
    }
}
/** 确定哪些行的cell可以编辑 (UITableViewDataSource协议中方法). */
-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}
//指定cell的编辑状态(删除还是插入)(UITableViewDelegate 协议方法)
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}

//
-(NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath{
    return @"删除";
}

/** 提交编辑状态 (UITableViewDataSource协议中方法). */
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    /**   点击 删除 按钮的操作 */
    if (editingStyle == UITableViewCellEditingStyleDelete) { /**< 判断编辑状态是删除时. */
        FriendsList *list = self.contactArr[indexPath.row];
//        NSLog(@"list.userId-%@",list.userId);
        NSString *url = [NSString stringWithFormat:@"%@ %@",MYURL,list.userId];
        url= [url stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
        
        [self.manager POST:url parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
            NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject  options:(NSJSONReadingMutableLeaves) error:nil];
            
            NSLog(@"删除好友返回信息：%@",dict);
            if ([dict[@"message"] isEqualToString:@"delete a friend successfully"]) {
                [self prompt:@"删除好友成功"];
                [self getURLData];
            }else{
                [self prompt:@"删除好友失败"];
            }
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            [self prompt:@"当前网络不可用"];
        }];
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    [self.contactArr addObjectsFromArray:[[FMDBTool shareDataBase]selectFriendsList]];
    FriendsList *s = self.contactArr[indexPath.row];
    FriendsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell=[[FriendsTableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
        
        cell.layer.opaque = YES;
        UILongPressGestureRecognizer *longClick = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(setEditing:animated:)];
        longClick.minimumPressDuration = 2;
        //取消点击效果
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [cell addGestureRecognizer:longClick];
        cell.backgroundColor = [UIColor clearColor];
    }
    cell.lab.text=s.name;
    cell.imageV.image=s.image;
    cell.imageV.layer.cornerRadius=cell.imageView.frame.size.width/2;
    cell.imageV.layer.masksToBounds=YES;
    cell.layer.opaque=YES;
    cell.selectionStyle = UITableViewCellSelectionStyleNone; 
    cell.imageV.image = [UIImage imageNamed:@"圆头像.png"];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (_cellRequest==NO) {
        FriendsList *list = self.contactArr[indexPath.row];
        self.friendName =list.name;
        [self getLocation:indexPath];
    }
}
//请求位好友位置
-(void)getLocation:(NSIndexPath *)index;{
    _cellRequest = YES;
    [SVProgressHUD showWithStatus:@"正在请求好友位置"];
    FriendsList *list = self.contactArr[index.row];
    self.phone = list.phone;
    NSString *url = [NSString stringWithFormat:@"http://api.sunsyi.com:8081/Track/lastposition/id/%@",list.userId];
    url= [url stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    
    [self.manager POST:url parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject  options:(NSJSONReadingMutableLeaves) error:nil];
        self.ar=[dict[@"content"] componentsSeparatedByString:@":"];
        [self lastPosition];
        NSLog(@"上传地理位置参数：%@",dict);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        [self  prompt:@"当前网络不可用"];
        _cellRequest = NO;
    }];
}
-(void)lastPosition{
    [SVProgressHUD dismiss];
    _cellRequest = NO;
    XYMapVC *mapVC = [[XYMapVC alloc]init];
    mapVC.longitude = [self.ar[0] doubleValue];
    mapVC.latitude = [self.ar[1] doubleValue];
    mapVC.name=self.friendName;
    mapVC.phone = self.phone;
    NSLog(@"%@当前经纬度%f:%f",mapVC.name,mapVC.longitude,mapVC.latitude);
    mapVC.titleStr = @"好友的位置";
    [self.navigationController pushViewController:mapVC animated:YES];
    
}
-(void)dissNetWork{
    [SVProgressHUD dismiss];
    [self.manager.operationQueue cancelAllOperations];
    [self prompt:@"好友当前网络状态较差,请稍后再试"];
    _cellRequest = NO;
}
//提示框
-(void)prompt:(NSString *)message{
    // 1.创建alert控制器
    UIAlertController *alertVc = [UIAlertController alertControllerWithTitle:@"提示" message:message preferredStyle:UIAlertControllerStyleAlert];
    // 2.添加按钮以及触发事件
    UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
    [alertVc addAction:action1];
    // 3.presentViewController弹出一个控制器
    [self presentViewController:alertVc animated:YES completion:nil];
}
-(AFHTTPSessionManager *)manager{
    if (!_manager) {
        _manager=[AFHTTPSessionManager manager];
        _manager.requestSerializer = [AFHTTPRequestSerializer serializer];
        _manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        //因AFNetworking 2.0开始格式有误，下面这句代码必须添加，否则有些格式无法识别
        _manager.responseSerializer.acceptableContentTypes=[NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html", nil];
    }
    return _manager;
}
-(NSMutableArray *)contactArr{
    if (!_contactArr) {
        _contactArr = [NSMutableArray array];
    }
    return _contactArr;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

@end
