//
//  ChangeUserNameView.h
//  Track
//
//  Created by apple on 16/9/20.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChangeUserNameView : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *userName;
@property (nonatomic,strong) NSString *name;
@end
