//
//  UpDataMessage.m
//  Track
//
//  Created by apple on 16/9/8.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "UpDataMessage.h"
#import "UIImageView+WebCache.h"
@implementation UpDataMessage
-(void)sdValue:(NSDictionary *)dic{
    self.userId = [dic valueForKey:@"id"];
    self.name = [dic valueForKey:@"name"];
    self.phone = [dic valueForKey:@"phone"];
    self.portrait = [dic valueForKey:@"portrait"];
    self.company = [dic valueForKey:@"company"];
    self.job = [dic valueForKey:@"job"];
    self.online =[NSString stringWithFormat:@"%@",dic[@"status"]];
    
    
    NSString *ss =[NSString stringWithFormat:@"http://api.sunsyi.com:8081/portrait/%@",_portrait];
    NSLog(@"下载图片接口%@",ss);
    [[SDWebImageManager sharedManager] downloadImageWithURL:[NSURL URLWithString:ss] options:0  progress:^(NSInteger receivedSize, NSInteger expectedSize)
     {
         //处理下载进度
     } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, BOOL finished, NSURL *imageURL) {
         if (error) {
            NSLog(@"下载自身头像错误：%@",error);
         }
         if (image) {
             NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
             NSString *filePath = [[paths objectAtIndex:0] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.png",self.phone]];   // 保存文件的名称
             [UIImagePNGRepresentation(image)writeToFile: filePath    atomically:YES];
             NSLog(@"自身图片保存路径：%@",filePath);
         }
     }];
    
}
//空实现
- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}

@end
