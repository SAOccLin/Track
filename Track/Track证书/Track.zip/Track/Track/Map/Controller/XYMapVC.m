//
//  XYMapVC.m
//  Track
//
//  Created by Mac on 16/8/16.
//  Copyright © 2016年 Mac. All rights reserved.
//



@interface XYMapVC ()<MKMapViewDelegate>
@property (nonatomic,strong)MKPinAnnotationView *annotationView;
@property (nonatomic,strong)id annotation;
@end

@implementation XYMapVC

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
    self.mapView.showsUserLocation = YES;//是否显示用户位置
    //比例尺
    self.mapView.showsScale = YES;
    //显示指南针
    self.mapView.showsCompass = YES;
    //显示交通
    self.mapView.showsTraffic = YES;
    //自动追踪到用户位置
    //    self.mapView.userTrackingMode = MKUserTrackingModeFollowWithHeading;
    
    self.navigationItem.title=_titleStr;
    _mapView.delegate=self;
    _mapView.mapType=MKMapTypeStandard;//地图类型
    
    //    NSLog(@"你说过%f,%f",self.longitude,self.latitude);
    CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(self.latitude, self.longitude);
    [self.mapView setRegion:MKCoordinateRegionMakeWithDistance(coordinate, 2000, 2000)];
    MapAnnotation *annotation = [[MapAnnotation alloc] init];
    annotation.coordinate = coordinate;
    NSString *friendLocation = [NSString stringWithFormat:@"%@的位置",self.name];
    annotation.title = friendLocation;
    
    [self.mapView addAnnotation:annotation];
}
//-(void)viewDidDisappear:(BOOL)animated{
//    [super viewDidDisappear:YES];
//    self.mapView = nil;
//    self.view = nil;
//    [self.view removeFromSuperview];
//}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor clearColor];
    
    UIBarButtonItem *delcedBtn=[[UIBarButtonItem alloc]initWithTitle:@"导航" style:UIBarButtonItemStylePlain target:self action:@selector(Navigation)];
    self.navigationItem.rightBarButtonItem=delcedBtn;
    
    //导航栏组建颜色设置
    [self.navigationController.navigationBar setTintColor:[UIColor whiteColor]];
}
- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    //    判断是不是用户的大头针数据模型
    if ([annotation isKindOfClass:[MKUserLocation class]]) {
        
        
    }else{
        MKAnnotationView *userView = [[MKAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:@"user"];
        
        UIImageView *imageView2 = [[UIImageView alloc]initWithFrame:CGRectMake(50, 200, 50, 70)];
        UIImage * image1 = [UIImage imageNamed:@"定位图标.png"];
        
        UIImage * image2 = [UIImage imageNamed:@"圆头像.png"];
        
        CGSize size = imageView2.frame.size;
        
        UIGraphicsBeginImageContext(size);
        
        [image1 drawInRect:CGRectMake(0, 0, size.width, size.height)];
        
        [image2 drawInRect:CGRectMake(3, 3, size.width-6, size.height-26)];
        
        UIImage *resultingImage =UIGraphicsGetImageFromCurrentImageContext();
        
        imageView2.image = resultingImage;
        
//        UIImage *img = [UIImage imageNamed:@"定位图标.png"];
//        CGSize imageSize = img.size;
//        
//        CGFloat width = imageSize.width;
//        CGFloat height = imageSize.height;
//        
//        CGFloat targetHeight = (25 / width) * height;
//        
//        UIGraphicsBeginImageContext(CGSizeMake(25, targetHeight));
//        [img drawInRect:CGRectMake(0, 0, 25, targetHeight)];
//        
//        UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
//        UIGraphicsEndImageContext();
        //        image 设置大头针视图的图片
        userView.image = imageView2.image;
        
        //  是否允许显示插入视图
        userView.canShowCallout = YES;
        
        return userView;
    }
//    self.annotationView = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"MapSample"];
////    self.annotationView.pinTintColor=[UIColor grayColor];
//    self.annotationView.image = [UIImage imageNamed:@"定位图标.png"];
//    self.annotationView.canShowCallout = YES;
//    self.annotation =annotation;
//

    return self.annotationView;
}

-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation{
    userLocation.title=@"您的位置";
    if ([self.annotation isKindOfClass:[MKUserLocation class]]) {
        self.annotationView.pinTintColor = [UIColor greenColor];
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
        NSString *filePath = [[paths objectAtIndex:0] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.png",self.phone]];   // 保存文件的名称
        UIImage *img = [UIImage imageWithContentsOfFile:filePath];
        
        CGSize imageSize = img.size;
        
        CGFloat width = imageSize.width;
        CGFloat height = imageSize.height;
        
        CGFloat targetHeight = (25 / width) * height;
        
        UIGraphicsBeginImageContext(CGSizeMake(25, targetHeight));
        [img drawInRect:CGRectMake(0, 0, 25, targetHeight)];
        
        UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
        self.annotationView.image = newImage;
     
//
    }

}
-(void)Navigation{
//    CLLocation *loc=[[CLLocation alloc]init];
////    loc.coordinate.latitude=[NSNumber numberWithDouble:self.latitude];
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"选取导航系统" message:nil preferredStyle:(UIAlertControllerStyleAlert)];
    
    
    //打开苹果自带地图
    UIAlertAction *openAppleMap= [UIAlertAction actionWithTitle:@"打开苹果自带地图" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action)
                                  {
                                      [self getMap];
                                  }];
    
//    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"baidumap://"]]) {
//        //打开百度地图
//        UIAlertAction *openBaiDuMap = [UIAlertAction actionWithTitle:@"百度地图" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action)
//                                       {
//                                           NSString *urlString = [[NSString stringWithFormat:@"baidumap://map/direction?origin=我的位置&destination=latlng:%f,%f|name=目的地&mode=driving&coord_type=gcj02&src=webapp.marker.yourCompanyName.yourAppName",self.latitude, self.longitude]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
//                                           [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString]];
//                                       }];
//        [alert addAction:openBaiDuMap];
//    }
    
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"iosamap://"]]) {
        //打开高德地图
        UIAlertAction *openGouldMap = [UIAlertAction actionWithTitle:@"打开高德地图" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action)
                                       {
                                           NSString *urlString = [[NSString stringWithFormat:@"iosamap://navi?sourceApplication=Track&backScheme=com.sunsyi.Track&lat=%f&lon=%f&dev=0&style=2",self.latitude,self.longitude] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
                                           [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString]];
                                       }];
        [alert addAction:openGouldMap];
    }
    
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"comgooglemaps://"]]) {
        //打开谷歌地图
        UIAlertAction *openGoogleMap = [UIAlertAction actionWithTitle:@"打开谷歌地图" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action)
                                        {
                                            NSString *urlString = [[NSString stringWithFormat:@"comgooglemaps://?x-source=Track&x-success=com.sunsyi.Track&saddr=&daddr=%f,%f&directionsmode=driving",self.longitude,self.latitude] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
                                            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString]];
                                        }];
        [alert addAction:openGoogleMap];
    }
    //取消按钮
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:(UIAlertActionStyleCancel) handler:nil];
    
    [alert addAction:openAppleMap];
    [alert addAction:cancel];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)getMap{
    CLLocationCoordinate2D loc = CLLocationCoordinate2DMake(self.latitude, self.longitude);
    MKMapItem *currentLocation = [MKMapItem mapItemForCurrentLocation];
    MKMapItem *toLocation = [[MKMapItem alloc] initWithPlacemark:[[MKPlacemark alloc] initWithCoordinate:loc addressDictionary:nil]];
    [MKMapItem openMapsWithItems:@[currentLocation, toLocation]
                   launchOptions:@{MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving,
                                   MKLaunchOptionsShowsTrafficKey: [NSNumber numberWithBool:YES]}];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
