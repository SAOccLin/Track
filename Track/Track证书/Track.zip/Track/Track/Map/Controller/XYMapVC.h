//
//  XYMapVC.h
//  Track
//
//  Created by Mac on 16/8/16.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import "MapAnnotation.h"
@interface XYMapVC : UIViewController
@property(strong,nonatomic)NSString *titleStr;
@property(nonatomic,assign)float longitude;
@property(nonatomic,assign)float latitude;
@property (nonatomic,strong)NSString *name;
@property (nonatomic,strong)NSString *phone;
@property (strong, nonatomic) IBOutlet MKMapView *mapView;



@end
