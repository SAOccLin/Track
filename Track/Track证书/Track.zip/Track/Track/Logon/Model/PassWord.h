//
//  PassWord.h
//  Track
//
//  Created by apple on 16/9/12.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PassWord : NSObject
@property (nonatomic,strong)NSString *name;
@property (nonatomic,strong)NSString *passWord;

@end
