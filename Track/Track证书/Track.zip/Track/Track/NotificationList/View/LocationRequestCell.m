//
//  LocationRequestCell.m
//  Track
//
//  Created by maralves on 16/9/4.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "LocationRequestCell.h"

@implementation LocationRequestCell

- (void)layoutSubviews{
    [super layoutSubviews];
    self.backgroundColor = [UIColor clearColor];
    _userimage.layer.cornerRadius=_userimage.frame.size.width/2;
    _userimage.layer.masksToBounds=YES;
    _userimage.image = [UIImage imageNamed:@"圆头像.png"];
    _time.textColor = [UIColor whiteColor];
    _content.textColor = [UIColor whiteColor];
}
- (void)setList:(NotificationList *)list{
    if (_list != list) {
        _list = list;
        self.content.text =list.name;
        self.userimage.image = list.image;
    }
}

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
