//
//  NotificationList.m
//  Track
//
//  Created by apple on 16/9/5.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "NotificationList.h"

@implementation NotificationList
-(void)dataDicValue:(NSDictionary<NSString *,id> *)dic{  
    self.userId = [dic valueForKey:@"id"];
    self.portrait = [dic valueForKey:@"url"];
    NSInteger createtime = [[dic valueForKey:@"time"]integerValue];
    NSArray *arr=[dic[@"appId"] componentsSeparatedByString:@"-"];
//    NSLog(@"哦你了%@",arr);
    if (arr.count==5) {
        self.name =[NSString stringWithFormat:@"%@请求添加你为好友",[dic valueForKey:@"name"]];
        
    }else if([dic[@"createtime"]isEqualToString:@"<null>"]|[dic[@"createtime"]isEqualToString:@"null"]|[dic[@"createtime"]isEqualToString:@"(null)"]|(dic[@"createtime"]==nil)){
        NSDate *nowDate =[NSDate dateWithTimeIntervalSince1970:createtime];
//        NSLog(@"我努力%@",nowDate);
        NSDateFormatter *dataFormatter = [[NSDateFormatter alloc]init];
        dataFormatter.dateFormat = @"YYYY-MM-dd hh:mm:ss";
        self.requestTime = [dataFormatter stringFromDate:nowDate];
        self.name = [NSString stringWithFormat:@"%@正在查看你的位置",dic[@"name"]];
    }
    
    NSURL *url =[NSURL URLWithString:self.portrait];
    [[SDWebImageManager sharedManager] downloadImageWithURL:url options:kNilOptions progress:^(NSInteger receivedSize, NSInteger expectedSize) {
        // receivedSize : 已经接受到的数据大小
        // expectedSize : 需要下载的图片的总大小
//        NSLog(@"正在下载 %zd %zd", receivedSize, expectedSize);
    } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, BOOL finished, NSURL *imageURL) {
        // image : 下载好的图片
        // error: 错误信息
        // cacheType: 缓存的类型
        // finished: 是否下载完成
        // imageURL: 被下载的图片的地址
//        NSLog(@"下载成功 %@", image);
        self.image=image;
    }];
}
//空实现
- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}


@end
