//
//  NotificationList.h
//  Track
//
//  Created by apple on 16/9/5.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NotificationList : NSObject
@property (nonatomic,strong)UIImage *image;
@property (nonatomic,strong)NSString *name;
@property (nonatomic,strong)NSString *requestTime;
@property (nonatomic,strong)NSString *portrait;
@property (nonatomic,strong)NSString *userId;
@property (nonatomic,strong)NSString *imageData;

-(void)dataDicValue:(NSDictionary<NSString *,id> *)dic;

@end
