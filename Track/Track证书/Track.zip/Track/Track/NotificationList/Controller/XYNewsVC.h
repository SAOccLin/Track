//
//  XYNewsVC.h
//  Track
//
//  Created by apple on 16/8/27.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NotificationList.h"

@interface XYNewsVC : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic,strong) NSMutableArray *positionArry;
@property (nonatomic,strong) NSMutableArray *positionArry2;
@property (nonatomic,strong) NSMutableArray *friendsArry;
@property (nonatomic,strong) NSMutableArray *friendsArry2;

-(void)getURLRequest;
-(void)addFriendRequest:(NSNotification *)data;

@end
